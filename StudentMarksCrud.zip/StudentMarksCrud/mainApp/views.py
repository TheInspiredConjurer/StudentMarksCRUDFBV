from django.shortcuts import render, redirect, get_object_or_404
from .forms import NewStudentForm, NewMarkForm
from .models import *

# Create your views here.

def ShowStudentList(request):
    student_list = Student.objects.all()
    return render(request, 'mainApp/StudentList.html', {'student_list': student_list})


def CreateNewStudent(request):
    form = NewStudentForm()
    if (request.method == 'POST'):
        form = NewStudentForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['studentName'])
            print(form.cleaned_data['departmentName'])
            student = Student()
            student.student_name = form.cleaned_data['studentName']
            student.department_name = form.cleaned_data['departmentName']
            student.save()
        return redirect('/')

    return render(request, 'mainApp/CreateNewStudent.html', {'form': form})


def UpdateStudentDetails(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = NewStudentForm(request.GET)
    if(request.method == 'POST'):
        form = NewStudentForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['studentName'])
            print(form.cleaned_data['departmentName'])
            student.student_name = form.cleaned_data['studentName']
            student.department_name = form.cleaned_data['departmentName']
            student.save()
            return redirect('StudentList')
    
    return render(request, 'mainApp/UpdateStudent.html', {'form': form, 'student': student})


def DeleteStudent(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if(request.method == 'POST'):
        if(student):
            student.delete()
            return redirect('StudentList')
    return render(request, 'mainApp/DeleteStudent.html', {'student': student})


def AddMark(request, pk):
    studentObject = get_object_or_404(Student, pk=pk)
    form = NewMarkForm()
    if (request.method == 'POST'):
        form = NewMarkForm(request.POST)
        if form.is_valid():
            newMark = Marks()
            newMark.student = studentObject
            newMark.subject = form.cleaned_data['subjectName']
            newMark.marks = form.cleaned_data['marks']
            newMark.save()
        return redirect('StudentList')

    return render(request, 'mainApp/AddMarksForSingleStudent.html', {'form': form, 'student': studentObject})


def StudentMarkDetails(request, pk):
    student = get_object_or_404(Student, pk=pk)
    queryset = Marks.objects.filter(student = student)
    return render(request, 'mainApp/MarkDetailsForSingleStudent.html', {'student': student, 'marksList': queryset})



def UpdateStudentMarkDetails(request, pk):
    marks = get_object_or_404(Marks, pk=pk)
    form = NewMarkForm(request.GET)
    if(request.method == 'POST'):
        form = NewMarkForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['subjectName'])
            print(form.cleaned_data['marks'])
            marks.subject = form.cleaned_data['subjectName']
            marks.marks = form.cleaned_data['marks']
            marks.save()
            return redirect('StudentMarkDetails', pk=marks.student.pk)
    
    return render(request, 'mainApp/UpdateMarksForSingleStudent.html', {'form': form, 'mark': marks})


def DeleteStudentMarkDetails(request, pk):
    mark = get_object_or_404(Marks, pk=pk)
    if(request.method == 'POST'):
        if(mark):
            mark.delete()
            return redirect('StudentList')
    return render(request, 'mainApp/DeleteMarksForSingleStudent.html', {'mark': mark})
