from django.db import models
from django.urls import reverse

# Create your models here.
class Student(models.Model):

  student_name=models.CharField(max_length=255, null=False, unique=False)
  department_name=models.CharField(max_length=255, null=False, unique=False)

  def __str__(self):
    return f"Student - {self.student_name}"


class Marks(models.Model):
  student=models.ForeignKey(to=Student, null=True, unique=False, on_delete=models.SET_NULL)
  subject=models.CharField(max_length=255, null=False, unique=False)
  marks=models.IntegerField()

  def __str__(self):
    return (f"{self.student.student_name} - Marks in {self.subject}")